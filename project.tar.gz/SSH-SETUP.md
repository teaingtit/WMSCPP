# 🔐 SSH Passphrase Setup Guide

## ปัญหา: ต้องใส่ passphrase ทุกครั้งที่ใช้ SSH

คุณใช้ SSH key ที่มี passphrase (`id_ed25519`) ซึ่ง**ปลอดภัยมาก**!
แต่ต้องพิมพ์ passphrase ซ้ำทุกครั้ง ซึ่งไม่สะดวก

---

## ✅ วิธีแก้: ใช้ SSH Agent (แนะนำ)

SSH Agent จะจำ passphrase ไว้ในหน่วยความจำชั่วคราว ไม่ต้องพิมพ์ซ้ำ

### 🔧 Setup (ทำครั้งเดียว)

#### Step 1: เปิด PowerShell แบบ Administrator

1. กด `Win + X`
2. เลือก **"Windows PowerShell (Admin)"** หรือ **"Terminal (Admin)"**

#### Step 2: เปิดและตั้งค่า ssh-agent

```powershell
# เปิด ssh-agent service
Set-Service ssh-agent -StartupType Automatic
Start-Service ssh-agent

# ตรวจสอบว่าเปิดแล้ว
Get-Service ssh-agent
```

ผลลัพธ์ที่ถูกต้อง:

```
Status   Name               DisplayName
------   ----               -----------
Running  ssh-agent          OpenSSH Authentication Agent
```

#### Step 3: เพิ่ม SSH key เข้า Agent

กลับมาที่ PowerShell ปกติ (ไม่ต้อง Admin):

```powershell
# เพิ่ม key เข้า agent
ssh-add ~/.ssh/id_ed25519
```

ระบบจะถาม passphrase **ครั้งเดียว**:

```
Enter passphrase for C:\Users\nteai/.ssh/id_ed25519: [พิมพ์ passphrase]
Identity added: C:\Users\nteai/.ssh/id_ed25519
```

#### Step 4: ทดสอบ

```powershell
# ทดสอบ SSH (ไม่ควรถาม passphrase อีก)
ssh home-server "echo 'Success!'"
```

✅ **ถ้าไม่ถาม passphrase = สำเร็จ!**

---

## 🔄 การใช้งานประจำวัน

### เมื่อเปิดเครื่องใหม่

ssh-agent จะรันอัตโนมัติ แต่ key จะหายไป ต้องเพิ่มใหม่:

```powershell
ssh-add ~/.ssh/id_ed25519
```

พิมพ์ passphrase **ครั้งเดียว** แล้วใช้งานได้ทั้งวัน

### เช็คว่า key อยู่ใน agent หรือไม่

```powershell
ssh-add -l
```

ถ้าเห็น key = พร้อมใช้งาน
ถ้าว่าง = ต้อง `ssh-add` ใหม่

---

## 🤖 Auto-load Key (Advanced - Optional)

ถ้าต้องการให้ key โหลดอัตโนมัติทุกครั้งที่เปิด PowerShell:

### Step 1: สร้าง PowerShell Profile

```powershell
# เช็คว่ามี profile หรือยัง
Test-Path $PROFILE

# ถ้าไม่มี สร้างใหม่
if (!(Test-Path $PROFILE)) {
    New-Item -Path $PROFILE -Type File -Force
}

# เปิดแก้ไข
notepad $PROFILE
```

### Step 2: เพิ่ม Script นี้ใน Profile

```powershell
# Auto-load SSH key
if (Get-Service ssh-agent -ErrorAction SilentlyContinue | Where-Object {$_.Status -eq 'Running'}) {
    $sshKeys = ssh-add -l 2>&1
    if ($sshKeys -match "no identities") {
        Write-Host "Loading SSH key..." -ForegroundColor Yellow
        ssh-add ~/.ssh/id_ed25519
    }
}
```

### Step 3: Save และ Restart PowerShell

ตอนนี้ทุกครั้งที่เปิด PowerShell:

- ถ้ายังไม่มี key ใน agent → จะถาม passphrase อัตโนมัติ
- ถ้ามี key แล้ว → ข้ามไป

---

## 🔒 ทางเลือกอื่น (ไม่แนะนำ)

### ❌ วิธีที่ 2: สร้าง Key ใหม่ไม่มี Passphrase

**ไม่แนะนำ** เพราะไม่ปลอดภัย แต่ถ้าต้องการ:

```powershell
# สร้าง key ใหม่
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519_nopass -C "your_email@example.com"

# เมื่อถาม passphrase กด Enter เลย (เว้นว่าง)

# Copy public key ไปที่ server
ssh-copy-id -i ~/.ssh/id_ed25519_nopass.pub home-server

# อัพเดต SSH config
notepad ~/.ssh/config
```

เปลี่ยน:

```ssh-config
Host home-server
    HostName 100.96.9.50
    User teaingtit
    Port 22
    IdentityFile ~/.ssh/id_ed25519_nopass  # ใช้ key ใหม่
```

⚠️ **ข้อเสีย:** ถ้ามีคนเข้าถึงเครื่องคุณได้ = เข้า server ได้ทันที

---

## 📋 สรุป

| วิธี                 | ความปลอดภัย | ความสะดวก  | แนะนำ                |
| -------------------- | ----------- | ---------- | -------------------- |
| **SSH Agent**        | ⭐⭐⭐⭐⭐  | ⭐⭐⭐⭐   | ✅ **แนะนำ**         |
| Auto-load Script     | ⭐⭐⭐⭐⭐  | ⭐⭐⭐⭐⭐ | ✅ สำหรับ power user |
| Key ไม่มี passphrase | ⭐⭐        | ⭐⭐⭐⭐⭐ | ❌ ไม่แนะนำ          |

---

## 🎯 Quick Start (TL;DR)

```powershell
# 1. เปิด PowerShell แบบ Admin
# กด Win+X → เลือก "Terminal (Admin)"

# 2. เปิด ssh-agent
Set-Service ssh-agent -StartupType Automatic
Start-Service ssh-agent

# 3. กลับมา PowerShell ปกติ
# เพิ่ม key
ssh-add ~/.ssh/id_ed25519

# 4. ทดสอบ
ssh home-server "echo 'Success!'"
```

✅ **เสร็จแล้ว!** ไม่ต้องพิมพ์ passphrase อีก (จนกว่าจะปิดเครื่อง)

---

**หมายเหตุ:** ทุกครั้งที่เปิดเครื่องใหม่ ต้องรัน `ssh-add ~/.ssh/id_ed25519` ครั้งเดียว หรือใช้ Auto-load Script ด้านบน
