export { supabaseBrowser } from '@/lib/supabase/client';
