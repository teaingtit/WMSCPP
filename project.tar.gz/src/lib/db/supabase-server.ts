export { createClient } from '@/lib/supabase/server';
