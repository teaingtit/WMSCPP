export { supabaseAdmin } from '@/lib/supabase/admin';
